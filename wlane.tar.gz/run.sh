#!/bin/bash

mono Program.exe
