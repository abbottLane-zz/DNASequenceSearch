William Lane
Ling 473
Project 4 - ReadMe

This project was pretty straightforward for the most part. I used C#, and build the Trie structure by defining TrieNodes which consisted of a String nodeID (ie,"a", "t", "c", "g", or "root") and a Dictionary<String, TrieNode>. The key is the nodeID and the value is a TrieNode child. I built the Trie as described in the assignment with no issue whatsoever.

The trouble came in the searching. I have a getMatches() function as a member of the Trie class, and it takes in the directory location of the current file we are processing, reads it into memory as a String, and parses it in the manner described in the assignment description. Conceptually, there is no issue: it makes sense and it performs what it needs to perform. The problem is running time. The first attempt, it ran in just under 3 hours (2:55:xx). I removed some unnecessary if statement checks in the j loop of the getMatches() method, stored the current character in its own variable as opposed to toString()ing it from its original location twice, and changed my file read-in method from File.ReadAllText to StreamReader.ReadToEnd() (because I read online that it was more efficient for large files). Still my program executed in 2:51:xx to std out. Interestingly, did execute in only 56 minutes when I'm wrote the std out output directly to the output file using the > operator in bash. But after reading what people on the forums were doing, I was not satisfied with this either.

Finally, I switched my TrieNode implementation from using a Dictionary to using an array where I assigned the array indices to stand in for a specific character: ie t=0, c=1, g=2, a=3. That way I can insert and search in constant time of a character because I know what index it is supposed to be at if it exists. I also implemented my addNode() and findNode() methods with a switch to more efficiently determine what to do with each character of the input. 

After all of these changes, my code executes in about 9 minutes. 
