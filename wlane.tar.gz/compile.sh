#!/bin/bash

gmcs Program.cs
